const { func } = require('prop-types');

const server = require('express')();
const http = require('http').createServer(server);
const io = require('socket.io')(http, {
    cors:{
        origin:"*"
    }
});

io.listen(5000)
io.on('connection', function (socket) {
    console.log('A user connected: ' + socket.id);
    socket.emit('idResponse', socket.id);

    socket.on('disconnect', function () {
        console.log('A user disconnected: ' + socket.id);
    });

    socket.on('messageMorse', function(data) {
        console.log(data)
        socket.to(data.id).emit('messageMorse', data.morse);
        console.log("message transmitted to " + data.id)
    });

    socket.on('message', function(mes){
        console.log(`received '${mes}'`);
    })
});


http.listen(3000, function () {
    console.log(`Server started!`);
});

